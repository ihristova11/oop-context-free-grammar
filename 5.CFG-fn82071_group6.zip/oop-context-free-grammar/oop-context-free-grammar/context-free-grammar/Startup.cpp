#include <iostream>
#include <vector>
#include <string>

#include "Engine.h"

int main()
{
	Engine::getInstance().start();

	return 0;
}